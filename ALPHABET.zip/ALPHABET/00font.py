import sys
from PIL import Image

val = input("Enter Value :")
msg = ["space.jpg"]
size = int(len(val))
v = iter(val)
for i in range(size):
    msg.append(next(v)+".jpg")
msg.append("space.jpg")
for i in range(size):
    if msg[i]==" .jpg":
        msg[i] = "space.jpg"
    
#print(msg)


images = [Image.open(x) for x in msg]
widths, heights = zip(*(i.size for i in images))

total_width = sum(widths)
max_height = max(heights)

new_im = Image.new('RGB', (total_width, max_height))

x_offset = 0
for im in images:
  new_im.paste(im, (x_offset,0))
  x_offset += im.size[0]

foutput = val[:5]+".jpg"
new_im.save(foutput)

